/* 
 * DATE SET DESCRIPTION
 * The data set consists of the following fields.
 * Athlete: This field consists of the athlete name
 * Age: This field consists of athlete ages
 * Country: This fields consists of the country names which participated in Olympics
 * Year: This field consists of the year
 * Closing Date: This field consists of the closing date of ceremony
 * Sport: Consists of the sports name
 * Gold Medals: No.of Gold medals
 * Silver Medals: No.of Silver medals
 * Bronze Medals: No.of Bronze medals
 * Total Medals: Consists of total no of medals
 */

/*
 * Find the total number of medals that each country win in swimming
 */

package com.olympics;
import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyOlympicsMapper extends Mapper<LongWritable,Text,Text,IntWritable>{
	public Text word = new Text();
	public static final IntWritable one = new IntWritable(1);
	public void OlympicsMap(LongWritable key,Text value, Context context) throws IOException, InterruptedException {
		
	}

}
