package com.olympics;

public class MyOlympicsReducer {

}
