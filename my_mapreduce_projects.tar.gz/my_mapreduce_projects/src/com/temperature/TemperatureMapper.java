package com.temperature;
import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TemperatureMapper extends Mapper<LongWritable, Text, Text, LongWritable>{
	public void maxTempMapper(LongWritable key,Text value, Context context) throws IOException, InterruptedException{
		String line = value.toString();
		String year = line.substring(7,11);
		int maxairTemperature;
		maxairTemperature = Integer.parseInt(line.substring(90, 96));
		context.write(new Text(year), new LongWritable(maxairTemperature));	
	}

}
