package com.temperature;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
public class TemperatureDriver {

	public static void main(String[] args) throws Exception
	{
		System.out.println("Starting MR JOb ");
		if (args.length != 2) {
		      System.out.printf("Usage: TemperatureDriver <input dir> <output dir>\n");
		      System.exit(-1);
		    }
			Configuration conf = new Configuration();
			@SuppressWarnings("deprecation")
			Job job = new Job(conf, "Max Temeprature");
			job.setJarByClass(TemperatureDriver.class);
			job.setMapperClass(com.temperature.TemperatureMapper.class);
			job.setReducerClass(com.temperature.TemperatureReducer.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(LongWritable.class);
			FileInputFormat.addInputPath(job, new Path(args[0]));
			FileOutputFormat.setOutputPath(job,new Path(args[1]));
			System.out.println("Execution begins");
			System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
