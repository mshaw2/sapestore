package com.wordcount;
import java.io.IOException;
import java.util.*;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyWordCountMapper extends Mapper<LongWritable,Text,Text,IntWritable>{
	public static final IntWritable one = new IntWritable(1);
	public Text word = new Text();
	public void wordCountMap(LongWritable key,Text value, Context context) throws IOException, InterruptedException {
		StringTokenizer tokens = new StringTokenizer(value.toString());
		while(tokens.hasMoreElements()){
			word.set(tokens.nextToken());
			context.write(word, one);
		}
	}
}
