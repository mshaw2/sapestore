package com.temperature;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class TemperatureReducer extends Reducer<Text, LongWritable, Text, LongWritable>{
	public void maxTempReducer(Text key, Iterable<LongWritable> value,Context context) throws Exception, InterruptedException{
		long maxtempyear=0;
		for(LongWritable val : value){
			if (val.get() > maxtempyear){
			maxtempyear=val.get();
			}
		}	
		context.write(key, new LongWritable(maxtempyear));
}
}
